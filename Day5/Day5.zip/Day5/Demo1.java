import java.util.Scanner;

class Demo1{
	public static void main(String args[]){
	
	Scanner sc = new Scanner(System.in);

	//int a = sc.nextInt();
	//float b = sc.nextFloat();
	//char c = sc.next().charAt(0);
	//String STR = sc.next();
	//sc.next();
	//String STR1 = sc.nextLine();

	//System.out.println("Value :"+ a);
	//System.out.println("Value :"+ b);
	//System.out.println("Value :"+ c);
	//System.out.println("Value :"+ STR);
	//System.out.println("Value :"+ STR1);

	//System.out.println("Value :"+ args);

	
	//Stirng str = "1"; 


	/*
	for(int i = 0;i < 5;i++){
		System.out.println(args[i]);
	}*/

	//System.out.println(args[0]-1);
	//System.out.println(1+1+args[0]);
	
	//System.out.println(1+1+args[0]+1+1);

	System.out.println(Integer.parseInt(args[0])-1);
	//Integer.parseInt() - Wrapper class in java

	


}




}